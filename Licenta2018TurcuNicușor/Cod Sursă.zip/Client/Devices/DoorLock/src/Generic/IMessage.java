package Generic;

public interface IMessage {
    void onCommand(String command);
}
