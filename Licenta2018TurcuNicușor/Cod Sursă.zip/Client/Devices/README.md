# Dispozitive
* ### [Laser de securitate](https://github.com/turcunicusor/Licenta/tree/master/Source%20Code/Client/Devices/SecurityLaser "Apasă aici pentru a accesa codul sursă.")
* ### [Lampă](https://github.com/turcunicusor/Licenta/tree/master/Source%20Code/Client/Devices/Lamp "Apasă aici pentru a accesa codul sursă.")
* ### [Încuietarea ușii](https://github.com/turcunicusor/Licenta/tree/master/Source%20Code/Client/Devices/DoorLock "Apasă aici pentru a accesa codul sursă.")
* ### [Bec](https://github.com/turcunicusor/Licenta/tree/master/Source%20Code/Client/Devices/LightBulb "Apasă aici pentru a accesa codul sursă.")

###### Creat de [_**`Nicușor TURCU`**_](https://github.com/turcunicusor "Github")
